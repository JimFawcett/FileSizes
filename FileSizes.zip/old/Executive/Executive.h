#pragma once
// Executive.h - 

/*
*  Command Line options:
*  path     - first argument
*  patterns - file name patterns
*  /s recursive directory tree traversal
*  
*/
#include <string>
#include <map>
#include <functional>
#include <set>
#include <vector>

class FileSizes
{
public:
  using Path = std::string;
  using File = std::string;
  using Size = size_t;
  using DataStore = std::multimap<Size, File, std::greater<Size>>;
  using Pattern = std::string;
  using Patterns = std::vector<Pattern>;

  int processCmdLine(int argc, char** argv);
  void usage();
  bool showCmdLine(int argc, char** argv);
private:
  DataStore store_;
  bool recurse_ = false;
};